import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";

import Dashboard from "./pages/Dashboard";
import Products from "./pages/Products";
import Orders from "./pages/Orders";
import Sales from "./pages/Sales";
import Customers from "./pages/Customers";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";

import Store from "./pages/Store";
import Checkout from "./pages/Checkout";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

import {
  Routes,
  Route,
  Navigate
} from "react-router-dom";

import {
  useEffect,
  useState
} from "react";

import {
  onAuthStateChanged
} from "firebase/auth";

import {
  doc,
  getDoc
} from "firebase/firestore";

import {
  auth,
  db
} from "./firebase";




// ADMIN LAYOUT

function AdminLayout(){

return (

<div className="flex min-h-screen bg-gray-100">

<Sidebar />

<div className="flex-1 flex flex-col">

<Navbar />

<main className="flex-1 p-6">

<Routes>

<Route path="/" element={<Dashboard />} />

<Route path="/products" element={<Products />} />

<Route path="/orders" element={<Orders />} />

<Route path="/sales" element={<Sales />} />

<Route path="/customers" element={<Customers />} />

<Route path="/reports" element={<Reports />} />

<Route path="/settings" element={<Settings />} />

</Routes>

</main>

</div>

</div>

);

}






export default function App(){


const [user,setUser] = useState<any>(null);

const [role,setRole] = useState("");

const [loading,setLoading] = useState(true);



useEffect(()=>{


const unsubscribe = onAuthStateChanged(

auth,

async(currentUser)=>{


setUser(currentUser);


if(currentUser){


const userRef = doc(
db,
"users",
currentUser.uid
);


const userSnap = await getDoc(userRef);



if(userSnap.exists()){

setRole(
userSnap.data().role
);

}


}


setLoading(false);


}

);



return unsubscribe;


},[]);







if(loading){

return(

<div className="h-screen flex items-center justify-center">

Loading...

</div>

);

}






return (

<Routes>


{/* LOGIN */}

<Route

path="/login"

element={

user ?

(

role === "admin"

?

<Navigate to="/" />

:

<Navigate to="/store" />

)

:

<Login />

}

/>






{/* SIGNUP */}

<Route

path="/signup"

element={

user ?

<Navigate to="/store" />

:

<Signup />

}

/>







{/* STORE USER */}

<Route

path="/store"

element={

user && role === "user"

?

<Store />

:

<Navigate to="/login" />

}

/>








{/* CHECKOUT */}

<Route

path="/checkout"

element={

user && role === "user"

?

<Checkout />

:

<Navigate to="/login" />

}

/>








{/* ADMIN */}

<Route

path="/*"

element={

user && role === "admin"

?

<AdminLayout />

:

<Navigate to="/store" />

}

/>



</Routes>

);


}