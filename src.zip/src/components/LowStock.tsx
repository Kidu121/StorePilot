const products = [
  {
    name: "Wireless Mouse",
    stock: 3,
  },
  {
    name: "Keyboard",
    stock: 2,
  },
  {
    name: "USB Cable",
    stock: 5,
  },
];

export default function LowStock() {
  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6">
      <h2 className="text-lg font-semibold mb-5">
        ⚠️ Low Stock
      </h2>

      <div className="space-y-4">
        {products.map((item) => (
          <div
            key={item.name}
            className="flex justify-between items-center"
          >
            <span className="text-gray-700">
              {item.name}
            </span>

            <span className="text-red-600 font-bold">
              {item.stock} left
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}