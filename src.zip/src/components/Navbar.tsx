import { useState, useEffect } from "react";
import { auth } from "../firebase";
import { signOut, onAuthStateChanged } from "firebase/auth";
import { useNavigate } from "react-router-dom";
import {
  Search,
  Bell,
  ChevronDown,
} from "lucide-react";


export default function Navbar() {

  const [profileOpen, setProfileOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);

  const [user, setUser] = useState<any>(null);

  const navigate = useNavigate();


  // Firebase user check
  useEffect(() => {

    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });

    return () => unsubscribe();

  }, []);



  // Logout
  const handleLogout = async () => {

    await signOut(auth);

    navigate("/login");

  };



  return (

    <header className="relative h-20 bg-white border-b border-gray-200 flex items-center justify-between px-8">


      {/* Search */}

      <div className="flex items-center bg-gray-100 rounded-xl px-4 py-2 w-96">

        <Search
          size={20}
          className="text-gray-400"
        />

        <input
          type="text"
          placeholder="Search products, customers..."
          className="bg-transparent outline-none ml-3 w-full text-sm"
        />

      </div>




      {/* Right Side */}

      <div className="flex items-center gap-6">



        {/* Notification */}

        <button
          onClick={() => setNotificationOpen(!notificationOpen)}
          className="relative"
        >

          <Bell
            size={22}
            className="text-gray-600"
          />


          <span
            className="
            absolute
            -top-2
            -right-2
            bg-red-500
            text-white
            text-xs
            w-5
            h-5
            rounded-full
            flex
            items-center
            justify-center
            "
          >
            3
          </span>


        </button>





        {/* Profile Button */}

        <button
          onClick={() => setProfileOpen(!profileOpen)}
          className="flex items-center gap-3"
        >


          <div
            className="
            w-10
            h-10
            rounded-full
            bg-blue-600
            text-white
            flex
            items-center
            justify-center
            font-bold
            "
          >

            {user?.email?.charAt(0).toUpperCase() || "K"}

          </div>




          <div className="text-left">


            <p className="text-sm font-semibold text-gray-900">

              {user?.email?.split("@")[0] || "Kidus"}

            </p>


            <p className="text-xs text-gray-500">

              Owner

            </p>


          </div>



          <ChevronDown
            size={18}
            className="text-gray-500"
          />


        </button>







        {/* Profile Dropdown */}


        {profileOpen && (


          <div
            className="
            absolute
            right-8
            top-16
            bg-white
            border
            border-gray-200
            rounded-xl
            shadow-lg
            w-48
            p-2
            z-50
            "
          >



            <button
              onClick={() => navigate("/profile")}
              className="
              w-full
              text-left
              px-4
              py-3
              rounded-lg
              hover:bg-gray-100
              "
            >

              Profile

            </button>





            <button
              onClick={() => navigate("/settings")}
              className="
              w-full
              text-left
              px-4
              py-3
              rounded-lg
              hover:bg-gray-100
              "
            >

              Settings

            </button>







            <button
              onClick={handleLogout}
              className="
              w-full
              text-left
              px-4
              py-3
              rounded-lg
              text-red-600
              hover:bg-gray-100
              "
            >

              Logout

            </button>




          </div>


        )}





      </div>


    </header>

  );

}