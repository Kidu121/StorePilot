const orders = [
  {
    id: "#1001",
    customer: "Abebe",
    product: "iPhone Case",
    amount: "850 ETB",
    status: "Paid",
  },
  {
    id: "#1002",
    customer: "Hana",
    product: "Keyboard",
    amount: "2,500 ETB",
    status: "Pending",
  },
  {
    id: "#1003",
    customer: "Samuel",
    product: "Mouse",
    amount: "1,200 ETB",
    status: "Paid",
  },
];

export default function RecentOrders() {
  return (
    <div className="bg-white rounded-2xl shadow-sm border p-6">
      <h2 className="text-xl font-semibold mb-5">Recent Orders</h2>

      <table className="w-full">
        <thead>
          <tr className="text-left text-gray-500 border-b">
            <th className="pb-3">Order</th>
            <th className="pb-3">Customer</th>
            <th className="pb-3">Product</th>
            <th className="pb-3">Amount</th>
            <th className="pb-3">Status</th>
          </tr>
        </thead>

        <tbody>
          {orders.map((order) => (
            <tr key={order.id} className="border-b last:border-0">
              <td className="py-4 font-medium">{order.id}</td>
              <td>{order.customer}</td>
              <td>{order.product}</td>
              <td>{order.amount}</td>

              <td>
                <span
                  className={`px-3 py-1 rounded-full text-sm ${
                    order.status === "Paid"
                      ? "bg-green-100 text-green-700"
                      : "bg-yellow-100 text-yellow-700"
                  }`}
                >
                  {order.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}