const products = [
  {
    name: "iPhone Case",
    sold: 120,
    revenue: "102,000 ETB",
  },
  {
    name: "Wireless Mouse",
    sold: 95,
    revenue: "57,000 ETB",
  },
  {
    name: "Mechanical Keyboard",
    sold: 72,
    revenue: "180,000 ETB",
  },
];

export default function TopProducts() {
  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6">
      <h2 className="text-lg font-semibold mb-5">
        🏆 Top Selling Products
      </h2>

      <div className="space-y-4">
        {products.map((product) => (
          <div
            key={product.name}
            className="flex justify-between items-center"
          >
            <div>
              <p className="font-medium text-gray-800">
                {product.name}
              </p>

              <p className="text-sm text-gray-500">
                {product.sold} sold
              </p>
            </div>

            <span className="font-semibold text-blue-600">
              {product.revenue}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}