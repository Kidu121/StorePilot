import { useState } from "react";

import { db } from "../firebase";

import {
  collection,
  addDoc,
  Timestamp
} from "firebase/firestore";



export default function Checkout(){


const [customerName,setCustomerName] = useState("");

const [phone,setPhone] = useState("");

const [address,setAddress] = useState("");

const [productName,setProductName] = useState("");

const [quantity,setQuantity] = useState("");

const [totalPrice,setTotalPrice] = useState("");

const [paymentStatus,setPaymentStatus] = useState(
"Cash on Delivery"
);



const placeOrder = async()=>{


if(
!customerName ||
!phone ||
!address ||
!productName ||
!quantity ||
!totalPrice
){

alert("Please fill all fields");

return;

}



await addDoc(

collection(db,"orders"),

{


customerName,

phone,

address,

productName,

quantity:Number(quantity),

totalPrice:Number(totalPrice),


orderStatus:"Pending",


paymentStatus,


createdAt:Timestamp.now()


}

);




alert("Order placed successfully");



// clear form

setCustomerName("");

setPhone("");

setAddress("");

setProductName("");

setQuantity("");

setTotalPrice("");



};





return(

<div className="max-w-xl mx-auto bg-white p-6 rounded-xl border">


<h1 className="text-3xl font-bold mb-6">

Place Order

</h1>




<div className="grid gap-4">



<input

placeholder="Customer Name"

value={customerName}

onChange={(e)=>setCustomerName(e.target.value)}

className="border p-3 rounded-lg"

/>




<input

placeholder="Phone Number"

value={phone}

onChange={(e)=>setPhone(e.target.value)}

className="border p-3 rounded-lg"

/>





<textarea

placeholder="Delivery Address"

value={address}

onChange={(e)=>setAddress(e.target.value)}

className="border p-3 rounded-lg"

/>





<input

placeholder="Product Name"

value={productName}

onChange={(e)=>setProductName(e.target.value)}

className="border p-3 rounded-lg"

/>





<input

type="number"

placeholder="Quantity"

value={quantity}

onChange={(e)=>setQuantity(e.target.value)}

className="border p-3 rounded-lg"

/>





<input

type="number"

placeholder="Total Price"

value={totalPrice}

onChange={(e)=>setTotalPrice(e.target.value)}

className="border p-3 rounded-lg"

/>





<select

value={paymentStatus}

onChange={(e)=>setPaymentStatus(e.target.value)}

className="border p-3 rounded-lg"

>


<option>
Cash on Delivery
</option>


<option>
Paid
</option>


</select>





<button

onClick={placeOrder}

className="bg-blue-600 text-white p-3 rounded-lg"

>

Place Order

</button>



</div>


</div>

);


}