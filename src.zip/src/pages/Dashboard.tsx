import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

import StatsCard from "../components/StatsCard";
import RecentOrders from "../components/RecentOrders";
import LowStock from "../components/LowStock";
import TopProducts from "../components/TopProducts";

const data = [
  { name: "Mon", sales: 4000 },
  { name: "Tue", sales: 3000 },
  { name: "Wed", sales: 6000 },
  { name: "Thu", sales: 5000 },
  { name: "Fri", sales: 8000 },
];

export default function Dashboard() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">
          Welcome back 👋
        </h1>

        <p className="text-gray-500 mt-2">
          Here's what's happening with your store today.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <StatsCard
          title="Today's Sales"
          value="12,500 ETB"
          trend="↑ 12%"
          icon="💰"
        />

        <StatsCard
          title="Profit"
          value="4,300 ETB"
          trend="↑ 8%"
          icon="📈"
        />

        <StatsCard
          title="Orders"
          value="25"
          trend="Today"
          icon="📦"
        />

        <StatsCard
          title="Products"
          value="180"
          trend="Available"
          icon="📋"
        />
      </div>

      {/* Chart + Low Stock */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 bg-white p-6 rounded-2xl border border-gray-200 shadow-sm h-80">
          <h2 className="text-xl font-semibold mb-4">
            Sales Overview
          </h2>

          <ResponsiveContainer width="100%" height="90%">
            <LineChart data={data}>
              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
              />

              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />

              <Line
                type="monotone"
                dataKey="sales"
                stroke="#2563eb"
                strokeWidth={3}
                dot={{ r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <LowStock />
      </div>

      {/* Recent Orders + Top Products */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2">
          <RecentOrders />
        </div>

        <TopProducts />
      </div>
    </div>
  );
}