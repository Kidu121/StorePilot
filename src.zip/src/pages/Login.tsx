import { useState } from "react";

import {
  signInWithEmailAndPassword
} from "firebase/auth";

import {
  doc,
  getDoc
} from "firebase/firestore";

import {
  auth,
  db
} from "../firebase";

import {
  useNavigate
} from "react-router-dom";



const Login = () => {


const [email,setEmail] = useState("");

const [password,setPassword] = useState("");

const navigate = useNavigate();




const handleLogin = async()=>{


try{


// Firebase Login

const userCredential = await signInWithEmailAndPassword(

auth,

email,

password

);



const user = userCredential.user;




// Get user role from Firestore

const userRef = doc(

db,

"users",

user.uid

);



const userSnap = await getDoc(userRef);



if(userSnap.exists()){


const role = userSnap.data().role;



if(role === "admin"){


navigate("/");


}

else if(role === "user"){


navigate("/store");


}


}

else{


alert("User profile not found");

}



}

catch(error:any){


alert(error.message);


}



};





return (

<div className="min-h-screen flex items-center justify-center bg-gray-100">


<div className="bg-white p-8 rounded-xl shadow-md w-96">


<h2 className="text-2xl font-bold mb-5">

Login

</h2>




<input

className="border p-3 w-full mb-3 rounded"

placeholder="Email"

type="email"

onChange={(e)=>setEmail(e.target.value)}

/>




<input

className="border p-3 w-full mb-3 rounded"

placeholder="Password"

type="password"

onChange={(e)=>setPassword(e.target.value)}

/>





<button

onClick={handleLogin}

className="bg-blue-600 text-white w-full p-3 rounded"

>

Login

</button>





<div className="mt-4 text-center">


<button

onClick={()=>navigate("/signup")}

className="text-blue-600"

>

Create Account

</button>


</div>



</div>


</div>


);


};


export default Login;