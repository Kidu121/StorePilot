import { useEffect, useState } from "react";

import { db } from "../firebase";

import {
  collection,
  getDocs,
  doc,
  updateDoc,
  deleteDoc
} from "firebase/firestore";


interface Order {

id:string;

customerName:string;

phone:string;

address:string;

productName:string;

quantity:number;

totalPrice:number;

orderStatus:string;

paymentStatus:string;

}



export default function Orders(){


const [orders,setOrders] = useState<Order[]>([]);



const ordersRef = collection(db,"orders");



// Get Orders

const getOrders = async()=>{


const data = await getDocs(ordersRef);


setOrders(

data.docs.map((item)=>(

{
id:item.id,
...item.data()

} as Order

))

);


};



useEffect(()=>{

getOrders();

},[]);





// Update Order Status

const updateOrderStatus = async(

id:string,

status:string

)=>{


await updateDoc(

doc(db,"orders",id),

{

orderStatus:status

}

);


getOrders();


};






// Update Payment Status

const updatePaymentStatus = async(

id:string,

status:string

)=>{


await updateDoc(

doc(db,"orders",id),

{

paymentStatus:status

}

);


getOrders();


};






// Delete Order

const deleteOrder = async(id:string)=>{


await deleteDoc(

doc(db,"orders",id)

);


getOrders();


};





return(

<div>


<h1 className="text-3xl font-bold mb-6">

Orders Management

</h1>





<div className="grid gap-5">



{

orders.map((order)=>(



<div

key={order.id}

className="bg-white border rounded-xl p-6"

>



<div className="grid grid-cols-2 gap-4">



<div>


<h2 className="font-bold text-xl">

{order.customerName}

</h2>


<p>
📞 {order.phone}
</p>


<p>
📍 {order.address}
</p>


</div>





<div>


<p>
Product: {order.productName}
</p>


<p>
Quantity: {order.quantity}
</p>


<p>
Total: {order.totalPrice} ETB
</p>


</div>



</div>





<div className="flex gap-4 mt-5">



<div>

<p className="font-semibold">
Order Status
</p>


<select

value={order.orderStatus}

onChange={(e)=>

updateOrderStatus(

order.id,

e.target.value

)

}

className="border p-2 rounded-lg"

>


<option>
Pending
</option>


<option>
Processing
</option>


<option>
Out for Delivery
</option>


<option>
Delivered
</option>


</select>


</div>







<div>


<p className="font-semibold">
Payment Status
</p>


<select

value={order.paymentStatus}

onChange={(e)=>

updatePaymentStatus(

order.id,

e.target.value

)

}

className="border p-2 rounded-lg"

>


<option>
Paid
</option>


<option>
Cash on Delivery
</option>


</select>



</div>






<button

onClick={()=>deleteOrder(order.id)}

className="text-red-600 ml-auto"

>

Delete

</button>



</div>




</div>


))


}





</div>



</div>

);


}