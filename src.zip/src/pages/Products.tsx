import { useState } from "react";

import ProductModal from "../components/products/ProductModal";
import ProductTable from "../components/products/ProductTable";
import SearchFilter from "../components/products/SearchFilter";


export default function Products() {


  const [openModal, setOpenModal] = useState(false);

  const [search, setSearch] = useState("");

  const [category, setCategory] = useState("");



  const handleAdd = () => {
    setOpenModal(true);
  };



  return (

    <div className="space-y-6">



      {/* Header */}

      <div className="flex justify-between items-center">


        <div>

          <h1 className="text-3xl font-bold">
            Products
          </h1>


          <p className="text-gray-500">
            Manage your inventory
          </p>


        </div>




        <button

          onClick={handleAdd}

          className="
          bg-blue-600
          text-white
          px-6
          py-3
          rounded-xl
          "

        >

          + Add Product

        </button>



      </div>





      {/* Search & Filter */}


      <SearchFilter

        search={search}

        setSearch={setSearch}

        category={category}

        setCategory={setCategory}

        onAdd={handleAdd}

      />







      {/* Product Table */}


      <ProductTable

        search={search}

      />







      {/* Add Product Modal */}


      {

        openModal && (

          <ProductModal

            close={() => setOpenModal(false)}

          />

        )

      }





    </div>

  );

}