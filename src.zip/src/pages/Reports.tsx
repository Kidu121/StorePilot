import {
  TrendingUp,
  ShoppingBag,
  Users,
  Package,
  DollarSign,
} from "lucide-react";


const salesData = [
  {
    month:"Jan",
    sales:"50,000 ETB"
  },
  {
    month:"Feb",
    sales:"80,000 ETB"
  },
  {
    month:"Mar",
    sales:"120,000 ETB"
  },
  {
    month:"Apr",
    sales:"95,000 ETB"
  },
];



export default function Reports(){


return (

<div className="space-y-6">



<div>

<h1 className="text-3xl font-bold text-gray-900">
Reports
</h1>


<p className="text-gray-500 mt-2">
Analyze your store performance.
</p>


</div>







<div className="
grid
grid-cols-1
md:grid-cols-4
gap-6
">





<div className="
bg-white
p-6
rounded-2xl
border
shadow-sm
">

<div className="flex justify-between">

<p className="text-gray-500">
Total Sales
</p>

<DollarSign className="text-green-600"/>

</div>


<h2 className="text-3xl font-bold mt-3">
250,000 ETB
</h2>


</div>






<div className="
bg-white
p-6
rounded-2xl
border
shadow-sm
">


<div className="flex justify-between">

<p className="text-gray-500">
Profit
</p>

<TrendingUp className="text-blue-600"/>

</div>


<h2 className="text-3xl font-bold mt-3">
85,000 ETB
</h2>


</div>







<div className="
bg-white
p-6
rounded-2xl
border
shadow-sm
">


<div className="flex justify-between">

<p className="text-gray-500">
Orders
</p>

<ShoppingBag className="text-purple-600"/>

</div>


<h2 className="text-3xl font-bold mt-3">
520
</h2>


</div>







<div className="
bg-white
p-6
rounded-2xl
border
shadow-sm
">


<div className="flex justify-between">

<p className="text-gray-500">
Customers
</p>

<Users className="text-orange-600"/>

</div>


<h2 className="text-3xl font-bold mt-3">
180
</h2>


</div>




</div>









<div className="
bg-white
rounded-2xl
border
p-6
">


<h2 className="
text-xl
font-semibold
mb-6
">

Sales Chart

</h2>




<div className="
space-y-5
">


{salesData.map((item)=>(


<div key={item.month}>


<div className="
flex
justify-between
mb-2
">

<span>
{item.month}
</span>


<span className="font-semibold">
{item.sales}
</span>


</div>



<div className="
h-3
bg-gray-100
rounded-full
">


<div

className="
h-3
bg-blue-600
rounded-full
"

style={{

width:
item.month==="Mar"
?"90%"
:
item.month==="Feb"
?"60%"
:
"40%"

}}

/>


</div>


</div>


))}



</div>


</div>









<div className="
bg-white
rounded-2xl
border
overflow-hidden
">


<h2 className="
text-xl
font-semibold
p-6
">

Best Selling Products

</h2>




<table className="w-full">


<thead className="bg-gray-50">


<tr>


<th className="p-4 text-left">
Product
</th>


<th className="p-4 text-left">
Sales
</th>


<th className="p-4 text-left">
Revenue
</th>


</tr>


</thead>




<tbody>


<tr className="border-t">

<td className="p-4 flex gap-2 items-center">

<Package size={18}/>

Laptop

</td>


<td>
120
</td>


<td className="text-green-600 font-semibold">
120,000 ETB
</td>


</tr>




<tr className="border-t">


<td className="p-4">
Keyboard
</td>


<td>
80
</td>


<td className="text-green-600 font-semibold">
20,000 ETB
</td>


</tr>



</tbody>


</table>


</div>






</div>


);


}