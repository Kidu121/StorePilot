import { useEffect, useState } from "react";
import { ShoppingCart } from "lucide-react";

import { db } from "../firebase";

import {
  collection,
  getDocs
} from "firebase/firestore";



interface Product {

id:string;

name:string;

description:string;

category:string;

sellingPrice:number;

quantity:number;

imageUrl:string;

}




export default function Store(){


const [products,setProducts] = useState<Product[]>([]);



const getProducts = async()=>{


const snapshot = await getDocs(

collection(db,"products")

);



setProducts(

snapshot.docs.map((item)=>(

{

id:item.id,

...item.data()

} as Product

))

);


};





useEffect(()=>{


getProducts();


},[]);







const addToCart = (product:Product)=>{


console.log("Added to cart",product);


alert(
`${product.name} added to cart`
);


};







return(


<div className="space-y-6">



<div>


<h1 className="text-3xl font-bold">

Store

</h1>


<p className="text-gray-500">

Choose your products

</p>


</div>








<div className="grid grid-cols-4 gap-5">





{

products.map((product)=>(


<div

key={product.id}

className="
bg-white
rounded-2xl
border
p-4
"

>





{

product.imageUrl && (

<img

src={product.imageUrl}

className="
w-full
h-48
object-cover
rounded-xl
"

/>

)

}







<h2 className="
font-bold
text-lg
mt-3
">

{product.name}

</h2>





<p className="text-gray-500">

{product.category}

</p>






<p className="
font-bold
text-blue-600
mt-2
">

{product.sellingPrice} ETB

</p>






<p>

Stock: {product.quantity}

</p>








<button

onClick={()=>addToCart(product)}

className="
mt-4
w-full
bg-blue-600
text-white
py-3
rounded-xl
flex
items-center
justify-center
gap-2
"

>


<ShoppingCart size={18}/>


Add To Cart


</button>







</div>


))


}





</div>







</div>


);


}